#!/usr/bin/env perl
use strict;
use warnings;

# assign variable
my $string = 'Hello World!';
# display value
print "$string\n";
